<?php
App::uses('AppModel', 'Model');
/**
 * Employee Model
 *
 */
class Employee extends AppModel {
    var $validate = array(
        'nazwisko' => array(
            'rule' => 'notBlank'), 
        'etat' => array(
            'rule' => 'notBlank'),
        'placa_pod' => array(
            'rule' => array('comparison', '>=', 0),
            'rule' => array('comparison', '<=', 2000),
            'message' => 'Must be between 0 and 2000'
        )
        );
}
